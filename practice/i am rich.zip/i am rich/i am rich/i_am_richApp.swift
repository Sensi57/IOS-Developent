//
//  i_am_richApp.swift
//  i am rich
//
//  Created by Алмагуль Абдыгали on 21.09.2024.
//

import SwiftUI

@main
struct i_am_richApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
