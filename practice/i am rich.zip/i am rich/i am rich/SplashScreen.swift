//
//  SplashScreen.swift
//  i am rich
//
//  Created by Алмагуль Абдыгали on 27.09.2024.
//

import SwiftUI

struct SplashScreen: View {
    var body: some View {
        ZStack{
            Color.white
                .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            Text("Welcome!")
                .font(.title)
                .foregroundColor(.black)
            
        }
    }
}

#Preview {
    SplashScreen()
}
